-- Club Avalanche Tables

-- Таблица членства в программах
CREATE TABLE IF NOT EXISTS gs_memberships (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  program VARCHAR(10) NOT NULL, -- GS-I, GS-II, GS-III, GS-IV
  referrer_id INTEGER REFERENCES users(id),
  referral_code VARCHAR(50) UNIQUE NOT NULL,
  purchase_date TIMESTAMP DEFAULT NOW(),
  amount_paid DECIMAL(20,8) NOT NULL,
  status VARCHAR(20) DEFAULT 'active',
  UNIQUE(user_id, program)
);

-- Таблица транзакций Club Avalanche
CREATE TABLE IF NOT EXISTS gs_transactions (
  id SERIAL PRIMARY KEY,
  from_user_id INTEGER REFERENCES users(id),
  to_user_id INTEGER REFERENCES users(id),
  program VARCHAR(10) NOT NULL,
  amount DECIMAL(20,8) NOT NULL,
  type VARCHAR(30) NOT NULL, -- purchase, referral_commission, gas_fee, to_reserve
  level INTEGER, -- уровень в иерархии (1-8)
  created_at TIMESTAMP DEFAULT NOW()
);

-- Таблица иерархий (для быстрого поиска древа)
CREATE TABLE IF NOT EXISTS gs_hierarchy (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  program VARCHAR(10) NOT NULL,
  level_1_id INTEGER REFERENCES users(id), -- прямой реферер
  level_2_id INTEGER REFERENCES users(id),
  level_3_id INTEGER REFERENCES users(id),
  level_4_id INTEGER REFERENCES users(id),
  level_5_id INTEGER REFERENCES users(id),
  level_6_id INTEGER REFERENCES users(id),
  level_7_id INTEGER REFERENCES users(id),
  level_8_id INTEGER REFERENCES users(id),
  UNIQUE(user_id, program)
);

-- Индексы для производительности
CREATE INDEX IF NOT EXISTS idx_gs_memberships_user ON gs_memberships(user_id);
CREATE INDEX IF NOT EXISTS idx_gs_memberships_referrer ON gs_memberships(referrer_id);
CREATE INDEX IF NOT EXISTS idx_gs_memberships_code ON gs_memberships(referral_code);
CREATE INDEX IF NOT EXISTS idx_gs_transactions_user ON gs_transactions(to_user_id);
CREATE INDEX IF NOT EXISTS idx_gs_hierarchy_user ON gs_hierarchy(user_id);
CREATE INDEX IF NOT EXISTS idx_gs_hierarchy_level1 ON gs_hierarchy(level_1_id);
