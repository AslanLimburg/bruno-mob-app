-- Lottery Draws Table
CREATE TABLE IF NOT EXISTS lottery_draws (
  id SERIAL PRIMARY KEY,
  draw_date TIMESTAMP NOT NULL UNIQUE,
  white_ball_1 INTEGER,
  white_ball_2 INTEGER,
  white_ball_3 INTEGER,
  white_ball_4 INTEGER,
  white_ball_5 INTEGER,
  powerball INTEGER,
  current_prize_pool NUMERIC(20, 8) DEFAULT 0,
  platform_balance NUMERIC(20, 8) DEFAULT 0,
  jackpot_contribution NUMERIC(20, 8) DEFAULT 0,
  total_tickets INTEGER DEFAULT 0,
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'drawn', 'checked', 'paid_out')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_lottery_draws_date ON lottery_draws(draw_date);
CREATE INDEX IF NOT EXISTS idx_lottery_draws_status ON lottery_draws(status);

-- Lottery Jackpot Table
CREATE TABLE IF NOT EXISTS lottery_jackpot (
  id INTEGER PRIMARY KEY DEFAULT 1,
  total_amount NUMERIC(20, 8) DEFAULT 100.00,
  last_won_date TIMESTAMP,
  last_won_amount NUMERIC(20, 8),
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO lottery_jackpot (id, total_amount) 
VALUES (1, 100.00) 
ON CONFLICT (id) DO NOTHING;

-- Lottery Tickets Table
CREATE TABLE IF NOT EXISTS lottery_tickets (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  draw_date TIMESTAMP NOT NULL,
  white_ball_1 INTEGER NOT NULL,
  white_ball_2 INTEGER NOT NULL,
  white_ball_3 INTEGER NOT NULL,
  white_ball_4 INTEGER NOT NULL,
  white_ball_5 INTEGER NOT NULL,
  powerball INTEGER NOT NULL,
  ticket_cost NUMERIC(10, 2) DEFAULT 2.00,
  draw_count INTEGER DEFAULT 1,
  remaining_draws INTEGER DEFAULT 1,
  status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'checked', 'winner', 'loser')),
  prize_category VARCHAR(10),
  prize_amount NUMERIC(20, 8) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_lottery_tickets_user ON lottery_tickets(user_id);
CREATE INDEX IF NOT EXISTS idx_lottery_tickets_draw ON lottery_tickets(draw_date);
CREATE INDEX IF NOT EXISTS idx_lottery_tickets_status ON lottery_tickets(status);

-- Prize Distribution Table
CREATE TABLE IF NOT EXISTS lottery_prize_distribution (
  id SERIAL PRIMARY KEY,
  category VARCHAR(10) UNIQUE NOT NULL,
  white_matches INTEGER NOT NULL,
  powerball_match BOOLEAN NOT NULL,
  pool_percentage NUMERIC(5, 2),
  fixed_amount NUMERIC(10, 2),
  description VARCHAR(255)
);

INSERT INTO lottery_prize_distribution (category, white_matches, powerball_match, pool_percentage, fixed_amount, description) 
VALUES
  ('6', 5, TRUE, 40.00, NULL, 'All 5 white + Powerball (Jackpot)'),
  ('5', 5, FALSE, 25.00, NULL, 'All 5 white balls'),
  ('4pb', 4, TRUE, 20.00, NULL, '4 white + Powerball'),
  ('4', 4, FALSE, 10.00, NULL, '4 white balls'),
  ('3pb', 3, TRUE, 4.00, NULL, '3 white + Powerball'),
  ('3', 3, FALSE, NULL, 1.00, '3 white balls (fixed 1 BRT)')
ON CONFLICT (category) DO NOTHING;

-- Lottery Payouts Table
CREATE TABLE IF NOT EXISTS lottery_payouts (
  id SERIAL PRIMARY KEY,
  ticket_id INTEGER NOT NULL REFERENCES lottery_tickets(id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  draw_date TIMESTAMP NOT NULL,
  prize_category VARCHAR(10) NOT NULL,
  prize_amount NUMERIC(20, 8) NOT NULL,
  paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_lottery_payouts_user ON lottery_payouts(user_id);
CREATE INDEX IF NOT EXISTS idx_lottery_payouts_draw ON lottery_payouts(draw_date);