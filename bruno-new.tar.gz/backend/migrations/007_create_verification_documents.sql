-- Migration: Create Verification Documents table for KYC/AML
-- Description: Stores user uploaded documents for identity verification
-- Date: 2025-10-27

-- Drop table if exists (для переустановки)
DROP TABLE IF EXISTS verification_documents CASCADE;

-- Create verification_documents table
CREATE TABLE verification_documents (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  document_type VARCHAR(50) NOT NULL, -- 'passport', 'id_card', 'driver_license', 'proof_of_address', 'selfie'
  document_url TEXT NOT NULL, -- URL документа (S3 или local storage)
  status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'approved', 'rejected'
  uploaded_at TIMESTAMP DEFAULT NOW(),
  reviewed_at TIMESTAMP,
  reviewed_by INTEGER REFERENCES users(id), -- ID админа который проверил
  rejection_reason TEXT, -- Причина отклонения если rejected
  notes TEXT, -- Дополнительные заметки админа
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Индексы для быстрого поиска
CREATE INDEX idx_verification_user_id ON verification_documents(user_id);
CREATE INDEX idx_verification_status ON verification_documents(status);
CREATE INDEX idx_verification_uploaded_at ON verification_documents(uploaded_at);
CREATE INDEX idx_verification_reviewed_by ON verification_documents(reviewed_by);

-- Триггер для обновления updated_at
CREATE OR REPLACE FUNCTION update_verification_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER verification_documents_updated_at
  BEFORE UPDATE ON verification_documents
  FOR EACH ROW
  EXECUTE FUNCTION update_verification_updated_at();

-- Комментарии
COMMENT ON TABLE verification_documents IS 'User uploaded documents for KYC/AML verification';
COMMENT ON COLUMN verification_documents.document_type IS 'Type of document: passport, id_card, driver_license, proof_of_address, selfie';
COMMENT ON COLUMN verification_documents.status IS 'Verification status: pending, approved, rejected';
COMMENT ON COLUMN verification_documents.rejection_reason IS 'Reason for rejection if status is rejected';

-- Готово!
SELECT 'Verification documents table created successfully!' as message;

