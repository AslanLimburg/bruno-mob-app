-- Bruno Messenger Tables

CREATE TABLE IF NOT EXISTS messages (
  id SERIAL PRIMARY KEY,
  from_user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  to_user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message_text TEXT,
  attachment_url TEXT,
  attachment_type VARCHAR(20), -- 'image', 'file', null
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW(),
  expires_at TIMESTAMP DEFAULT NOW() + INTERVAL '3 minutes',
  is_deleted BOOLEAN DEFAULT FALSE
);

-- Индексы для быстрого поиска
CREATE INDEX idx_messages_from_user ON messages(from_user_id) WHERE NOT is_deleted;
CREATE INDEX idx_messages_to_user ON messages(to_user_id) WHERE NOT is_deleted;
CREATE INDEX idx_messages_expires ON messages(expires_at) WHERE NOT is_deleted;
CREATE INDEX idx_messages_conversation ON messages(from_user_id, to_user_id) WHERE NOT is_deleted;

-- Таблица для списка контактов (чтобы быстро найти, с кем есть переписка)
CREATE TABLE IF NOT EXISTS messenger_contacts (
  id SERIAL PRIMARY KEY,
  user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  contact_user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  last_message_at TIMESTAMP DEFAULT NOW(),
  unread_count INT DEFAULT 0,
  UNIQUE(user_id, contact_user_id)
);

CREATE INDEX idx_messenger_contacts_user ON messenger_contacts(user_id);
CREATE INDEX idx_messenger_contacts_last_message ON messenger_contacts(user_id, last_message_at DESC);

COMMENT ON TABLE messages IS 'Bruno Messenger: P2P messages with 3-minute auto-deletion';
COMMENT ON TABLE messenger_contacts IS 'Bruno Messenger: Contact list with unread counts';
