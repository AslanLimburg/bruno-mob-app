-- =====================================================
-- BRT STARS CHALLENGE DATABASE SCHEMA
-- Migration: 005_create_stars_challenge_tables.sql
-- Date: 2025-10-17
-- =====================================================

-- =====================================================
-- 1. USERS PHOTOS
-- =====================================================
CREATE TABLE IF NOT EXISTS stars_photos (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  photo_url VARCHAR(500) NOT NULL,
  cloudinary_public_id VARCHAR(255), -- для Cloudinary
  is_main_photo BOOLEAN DEFAULT FALSE,
  upload_date TIMESTAMPTZ DEFAULT NOW(),
  expires_at TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '365 days'),
  last_renewed_at TIMESTAMPTZ,
  total_stars INTEGER DEFAULT 0, -- денормализация для быстрого доступа
  status VARCHAR(20) DEFAULT 'active', -- active, expired, deleted, pending_moderation
  moderation_status VARCHAR(20) DEFAULT 'pending', -- pending, approved, rejected
  moderation_result JSONB, -- результат AI модерации
  moderated_at TIMESTAMPTZ,
  moderated_by INTEGER REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Индексы для быстрого поиска
CREATE INDEX idx_stars_photos_user_id ON stars_photos(user_id);
CREATE INDEX idx_stars_photos_status ON stars_photos(status);
CREATE INDEX idx_stars_photos_moderation ON stars_photos(moderation_status);
CREATE INDEX idx_stars_photos_expires ON stars_photos(expires_at) WHERE status = 'active';
CREATE INDEX idx_stars_photos_main ON stars_photos(user_id, is_main_photo) WHERE is_main_photo = true;

-- Триггер для автоматического обновления updated_at
CREATE OR REPLACE FUNCTION update_stars_photos_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_stars_photos_timestamp
BEFORE UPDATE ON stars_photos
FOR EACH ROW
EXECUTE FUNCTION update_stars_photos_timestamp();

-- =====================================================
-- 2. PHOTO VOTES (Stars)
-- =====================================================
CREATE TABLE IF NOT EXISTS stars_photo_votes (
  id SERIAL PRIMARY KEY,
  photo_id INTEGER NOT NULL REFERENCES stars_photos(id) ON DELETE CASCADE,
  from_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  stars_count INTEGER NOT NULL CHECK (stars_count > 0 AND stars_count <= 50), -- лимит 50
  brt_amount DECIMAL(20,8) NOT NULL, -- сколько BRT было отправлено
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(photo_id, from_user_id) -- один юзер = один голос за фото
);

CREATE INDEX idx_stars_votes_photo ON stars_photo_votes(photo_id);
CREATE INDEX idx_stars_votes_user ON stars_photo_votes(from_user_id);
CREATE INDEX idx_stars_votes_created ON stars_photo_votes(created_at);

-- =====================================================
-- 3. GALLERY NOMINATIONS
-- =====================================================
CREATE TABLE IF NOT EXISTS stars_gallery_nominations (
  id SERIAL PRIMARY KEY,
  title VARCHAR(200) NOT NULL, -- "Лучшая танцовщица недели"
  description TEXT,
  created_by INTEGER NOT NULL REFERENCES users(id),
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_nominations_active ON stars_gallery_nominations(is_active);

-- =====================================================
-- 4. STARS CHALLENGES
-- =====================================================
CREATE TABLE IF NOT EXISTS stars_challenges (
  id SERIAL PRIMARY KEY,
  nomination_id INTEGER REFERENCES stars_gallery_nominations(id),
  title VARCHAR(200) NOT NULL,
  description TEXT,
  created_by INTEGER NOT NULL REFERENCES users(id), -- admin who created
  admin_wallet VARCHAR(100), -- кошелёк админа для 10% комиссии
  min_stake INTEGER DEFAULT 1, -- минимум Stars для голосования
  max_stake INTEGER DEFAULT 50, -- максимум Stars
  start_date TIMESTAMPTZ DEFAULT NOW(),
  end_date TIMESTAMPTZ NOT NULL,
  status VARCHAR(20) DEFAULT 'active', -- active, completed, cancelled
  total_pool DECIMAL(20,8) DEFAULT 0, -- общий призовой фонд в BRT
  winner_photo_id INTEGER REFERENCES stars_photos(id),
  winner_user_id INTEGER REFERENCES users(id),
  winner_total_votes INTEGER,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_stars_challenges_status ON stars_challenges(status);
CREATE INDEX idx_stars_challenges_nomination ON stars_challenges(nomination_id);
CREATE INDEX idx_stars_challenges_dates ON stars_challenges(start_date, end_date);
CREATE INDEX idx_stars_challenges_winner ON stars_challenges(winner_user_id);

-- =====================================================
-- 5. CHALLENGE PARTICIPANTS
-- =====================================================
CREATE TABLE IF NOT EXISTS stars_challenge_participants (
  id SERIAL PRIMARY KEY,
  challenge_id INTEGER NOT NULL REFERENCES stars_challenges(id) ON DELETE CASCADE,
  photo_id INTEGER NOT NULL REFERENCES stars_photos(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  total_votes INTEGER DEFAULT 0, -- сумма Stars за этот Challenge
  total_brt_collected DECIMAL(20,8) DEFAULT 0, -- сколько BRT собрано
  rank INTEGER, -- позиция в челлендже (1, 2, 3...)
  is_winner BOOLEAN DEFAULT FALSE,
  joined_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(challenge_id, photo_id) -- одно фото = один раз в челлендже
);

CREATE INDEX idx_participants_challenge ON stars_challenge_participants(challenge_id);
CREATE INDEX idx_participants_photo ON stars_challenge_participants(photo_id);
CREATE INDEX idx_participants_user ON stars_challenge_participants(user_id);
CREATE INDEX idx_participants_rank ON stars_challenge_participants(challenge_id, rank);

-- =====================================================
-- 6. CHALLENGE VOTES (голосование в челленджах)
-- =====================================================
CREATE TABLE IF NOT EXISTS stars_challenge_votes (
  id SERIAL PRIMARY KEY,
  challenge_id INTEGER NOT NULL REFERENCES stars_challenges(id) ON DELETE CASCADE,
  participant_id INTEGER NOT NULL REFERENCES stars_challenge_participants(id) ON DELETE CASCADE,
  from_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  stars_count INTEGER NOT NULL CHECK (stars_count > 0 AND stars_count <= 50),
  brt_amount DECIMAL(20,8) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(challenge_id, participant_id, from_user_id) -- один голос за участника
);

CREATE INDEX idx_challenge_votes_challenge ON stars_challenge_votes(challenge_id);
CREATE INDEX idx_challenge_votes_participant ON stars_challenge_votes(participant_id);
CREATE INDEX idx_challenge_votes_voter ON stars_challenge_votes(from_user_id);

-- =====================================================
-- 7. GALLERY WINNERS (52 недели)
-- =====================================================
CREATE TABLE IF NOT EXISTS stars_gallery_winners (
  id SERIAL PRIMARY KEY,
  nomination_id INTEGER NOT NULL REFERENCES stars_gallery_nominations(id),
  challenge_id INTEGER NOT NULL REFERENCES stars_challenges(id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  photo_id INTEGER NOT NULL REFERENCES stars_photos(id),
  week_number INTEGER NOT NULL, -- 1-52
  year INTEGER NOT NULL,
  total_stars INTEGER NOT NULL,
  total_brt_won DECIMAL(20,8) NOT NULL,
  rank INTEGER NOT NULL, -- позиция в недельном рейтинге (1-52)
  win_date TIMESTAMPTZ DEFAULT NOW(),
  expires_at TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '365 days'), -- фото удаляется через год
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(nomination_id, week_number, year, rank) -- один ранг = одна неделя
);

CREATE INDEX idx_gallery_nomination ON stars_gallery_winners(nomination_id);
CREATE INDEX idx_gallery_week ON stars_gallery_winners(year, week_number);
CREATE INDEX idx_gallery_user ON stars_gallery_winners(user_id);
CREATE INDEX idx_gallery_rank ON stars_gallery_winners(nomination_id, rank);
CREATE INDEX idx_gallery_expires ON stars_gallery_winners(expires_at);

-- =====================================================
-- 8. REWARD DISTRIBUTION HISTORY
-- =====================================================
CREATE TABLE IF NOT EXISTS stars_reward_history (
  id SERIAL PRIMARY KEY,
  challenge_id INTEGER NOT NULL REFERENCES stars_challenges(id),
  recipient_user_id INTEGER NOT NULL REFERENCES users(id),
  recipient_type VARCHAR(20) NOT NULL, -- winner, platform, admin, voter
  amount DECIMAL(20,8) NOT NULL,
  percentage DECIMAL(5,2), -- процент от пула
  transaction_id INTEGER REFERENCES transactions(id),
  distributed_at TIMESTAMPTZ DEFAULT NOW(),
  notes TEXT
);

CREATE INDEX idx_rewards_challenge ON stars_reward_history(challenge_id);
CREATE INDEX idx_rewards_recipient ON stars_reward_history(recipient_user_id);
CREATE INDEX idx_rewards_type ON stars_reward_history(recipient_type);

-- =====================================================
-- 9. PRIVACY & FRIENDS
-- =====================================================
CREATE TABLE IF NOT EXISTS stars_friends (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  friend_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status VARCHAR(20) DEFAULT 'pending', -- pending, accepted, rejected, blocked
  requested_at TIMESTAMPTZ DEFAULT NOW(),
  responded_at TIMESTAMPTZ,
  UNIQUE(user_id, friend_user_id)
);

CREATE INDEX idx_friends_user ON stars_friends(user_id);
CREATE INDEX idx_friends_friend ON stars_friends(friend_user_id);
CREATE INDEX idx_friends_status ON stars_friends(status);

-- =====================================================
-- 10. PRIVACY SETTINGS
-- =====================================================
CREATE TABLE IF NOT EXISTS stars_privacy_settings (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE UNIQUE,
  profile_visibility VARCHAR(20) DEFAULT 'public', -- public, friends_only, private
  allow_friend_requests BOOLEAN DEFAULT TRUE,
  show_online_status BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_privacy_user ON stars_privacy_settings(user_id);

-- =====================================================
-- TRIGGERS & FUNCTIONS
-- =====================================================

-- Функция для автоматического обновления total_stars на фото
CREATE OR REPLACE FUNCTION update_photo_total_stars()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE stars_photos 
    SET total_stars = total_stars + NEW.stars_count
    WHERE id = NEW.photo_id;
  ELSIF TG_OP = 'UPDATE' THEN
    UPDATE stars_photos 
    SET total_stars = total_stars - OLD.stars_count + NEW.stars_count
    WHERE id = NEW.photo_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE stars_photos 
    SET total_stars = total_stars - OLD.stars_count
    WHERE id = OLD.photo_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_photo_total_stars
AFTER INSERT OR UPDATE OR DELETE ON stars_photo_votes
FOR EACH ROW
EXECUTE FUNCTION update_photo_total_stars();

-- Функция для автоматического обновления participant stats
CREATE OR REPLACE FUNCTION update_participant_stats()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE stars_challenge_participants
    SET 
      total_votes = total_votes + NEW.stars_count,
      total_brt_collected = total_brt_collected + NEW.brt_amount
    WHERE id = NEW.participant_id;
    
    -- Обновить общий пул челленджа
    UPDATE stars_challenges
    SET total_pool = total_pool + NEW.brt_amount
    WHERE id = NEW.challenge_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_participant_stats
AFTER INSERT ON stars_challenge_votes
FOR EACH ROW
EXECUTE FUNCTION update_participant_stats();

-- =====================================================
-- DEFAULT DATA
-- =====================================================

-- Создать дефолтные настройки приватности для существующих пользователей
INSERT INTO stars_privacy_settings (user_id, profile_visibility, allow_friend_requests, show_online_status)
SELECT id, 'public', true, true
FROM users
WHERE id NOT IN (SELECT user_id FROM stars_privacy_settings)
ON CONFLICT (user_id) DO NOTHING;

-- Создать дефолтную номинацию
INSERT INTO stars_gallery_nominations (title, description, created_by, is_active)
VALUES 
  ('Лучшее фото недели', 'Еженедельный конкурс на лучшее фото', 1, true)
ON CONFLICT DO NOTHING;

-- =====================================================
-- COMMENTS
-- =====================================================
COMMENT ON TABLE stars_photos IS 'Фотографии пользователей для Stars Challenge';
COMMENT ON TABLE stars_photo_votes IS 'Голосование Stars за фото (лайки)';
COMMENT ON TABLE stars_challenges IS 'Челленджи (конкурсы фото)';
COMMENT ON TABLE stars_challenge_participants IS 'Участники челленджей';
COMMENT ON TABLE stars_challenge_votes IS 'Голосование в челленджах';
COMMENT ON TABLE stars_gallery_winners IS 'Галерея победителей (52 недели)';
COMMENT ON TABLE stars_reward_history IS 'История распределения наград';
COMMENT ON TABLE stars_friends IS 'Система друзей';
COMMENT ON TABLE stars_privacy_settings IS 'Настройки приватности';

-- =====================================================
-- END OF MIGRATION
-- =====================================================