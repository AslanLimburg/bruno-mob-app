-- Таблица для активационных кодов
CREATE TABLE IF NOT EXISTS activation_codes (
    id SERIAL PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    amount_usd DECIMAL(10, 2) NOT NULL,
    amount_brt DECIMAL(18, 8) NOT NULL,
    stripe_payment_id VARCHAR(255),
    stripe_session_id VARCHAR(255),
    buyer_email VARCHAR(255) NOT NULL,
    activated_by_user_id INTEGER REFERENCES users(id),
    activated_at TIMESTAMP,
    status VARCHAR(20) DEFAULT 'pending', -- pending, sent, activated, expired
    expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Индексы
CREATE INDEX idx_activation_codes_code ON activation_codes(code);
CREATE INDEX idx_activation_codes_status ON activation_codes(status);
CREATE INDEX idx_activation_codes_buyer_email ON activation_codes(buyer_email);
CREATE INDEX idx_activation_codes_activated_by ON activation_codes(activated_by_user_id);

-- Триггер для updated_at
CREATE OR REPLACE FUNCTION update_activation_codes_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER activation_codes_updated_at
    BEFORE UPDATE ON activation_codes
    FOR EACH ROW
    EXECUTE FUNCTION update_activation_codes_updated_at();
