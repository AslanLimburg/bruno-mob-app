-- ============================================
-- CHALLENGE 2.0 DATABASE SCHEMA
-- ============================================

-- 1. CHALLENGES (main table)
CREATE TABLE IF NOT EXISTS challenges (
  id SERIAL PRIMARY KEY,
  creator_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  
  -- Payout configuration
  payout_mode VARCHAR(20) NOT NULL DEFAULT 'pool_based', -- 'pool_based' or 'fixed_creator_prize'
  creator_prize_reserved DECIMAL(20,8) DEFAULT 0, -- Reserved prize for fixed mode
  
  -- Participation rules
  min_stake DECIMAL(20,8) DEFAULT 1,
  max_stake DECIMAL(20,8),
  allow_creator_participation BOOLEAN DEFAULT false,
  
  -- Timing
  open_accepting_at TIMESTAMP,
  close_accepting_at TIMESTAMP,
  resolve_deadline TIMESTAMP,
  
  -- Status
  status VARCHAR(20) NOT NULL DEFAULT 'draft', 
  -- Status: 'draft', 'open', 'closed_for_bets', 'resolved', 'disputed', 'cancelled'
  
  -- Result
  winning_option_id INTEGER, -- FK to challenge_options
  resolved_at TIMESTAMP,
  resolved_by INTEGER REFERENCES users(id),
  
  -- Visibility
  visibility VARCHAR(20) DEFAULT 'public', -- 'public', 'private'
  
  -- Timestamps
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  
  -- Constraints
  CONSTRAINT valid_payout_mode CHECK (payout_mode IN ('pool_based', 'fixed_creator_prize')),
  CONSTRAINT valid_status CHECK (status IN ('draft', 'open', 'closed_for_bets', 'resolved', 'disputed', 'cancelled')),
  CONSTRAINT valid_stakes CHECK (min_stake > 0 AND (max_stake IS NULL OR max_stake >= min_stake))
);

CREATE INDEX idx_challenges_creator ON challenges(creator_id);
CREATE INDEX idx_challenges_status ON challenges(status);
CREATE INDEX idx_challenges_timing ON challenges(open_accepting_at, close_accepting_at);

-- 2. CHALLENGE OPTIONS (possible outcomes)
CREATE TABLE IF NOT EXISTS challenge_options (
  id SERIAL PRIMARY KEY,
  challenge_id INTEGER NOT NULL REFERENCES challenges(id) ON DELETE CASCADE,
  option_text VARCHAR(255) NOT NULL,
  option_order INTEGER DEFAULT 1,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_challenge_options_challenge ON challenge_options(challenge_id);

-- 3. BETS (user stakes)
CREATE TABLE IF NOT EXISTS bets (
  id SERIAL PRIMARY KEY,
  challenge_id INTEGER NOT NULL REFERENCES challenges(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  option_id INTEGER NOT NULL REFERENCES challenge_options(id) ON DELETE CASCADE,
  
  amount DECIMAL(20,8) NOT NULL,
  status VARCHAR(20) DEFAULT 'active', -- 'active', 'won', 'lost', 'refunded'
  payout DECIMAL(20,8) DEFAULT 0,
  
  -- Idempotency
  idempotency_key VARCHAR(255) UNIQUE,
  
  created_at TIMESTAMP DEFAULT NOW(),
  
  CONSTRAINT valid_amount CHECK (amount > 0),
  CONSTRAINT valid_bet_status CHECK (status IN ('active', 'won', 'lost', 'refunded'))
);

CREATE INDEX idx_bets_challenge ON bets(challenge_id);
CREATE INDEX idx_bets_user ON bets(user_id);
CREATE INDEX idx_bets_option ON bets(option_id);
CREATE INDEX idx_bets_idempotency ON bets(idempotency_key);

-- 4. CHALLENGE LEDGER (ACID transaction log)
CREATE TABLE IF NOT EXISTS challenge_ledger (
  id SERIAL PRIMARY KEY,
  challenge_id INTEGER REFERENCES challenges(id) ON DELETE CASCADE,
  bet_id INTEGER REFERENCES bets(id) ON DELETE SET NULL,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  transaction_type VARCHAR(30) NOT NULL,
  -- Types: 'stake_locked', 'creator_prize_reserve', 'payout', 'commission', 'refund'
  
  amount DECIMAL(20,8) NOT NULL,
  balance_before DECIMAL(20,8) NOT NULL,
  balance_after DECIMAL(20,8) NOT NULL,
  
  description TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  
  CONSTRAINT valid_transaction_type CHECK (
    transaction_type IN ('stake_locked', 'creator_prize_reserve', 'payout', 'commission', 'refund')
  )
);

CREATE INDEX idx_ledger_challenge ON challenge_ledger(challenge_id);
CREATE INDEX idx_ledger_user ON challenge_ledger(user_id);
CREATE INDEX idx_ledger_type ON challenge_ledger(transaction_type);

-- 5. DISPUTES (user challenges to results)
CREATE TABLE IF NOT EXISTS disputes (
  id SERIAL PRIMARY KEY,
  challenge_id INTEGER NOT NULL REFERENCES challenges(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  reason TEXT NOT NULL,
  evidence TEXT,
  
  status VARCHAR(20) DEFAULT 'open', -- 'open', 'under_review', 'resolved'
  
  -- SLA tracking
  created_at TIMESTAMP DEFAULT NOW(),
  deadline TIMESTAMP, -- created_at + 72 hours
  
  CONSTRAINT valid_dispute_status CHECK (status IN ('open', 'under_review', 'resolved'))
);

CREATE INDEX idx_disputes_challenge ON disputes(challenge_id);
CREATE INDEX idx_disputes_status ON disputes(status);
CREATE INDEX idx_disputes_deadline ON disputes(deadline);

-- 6. DISPUTE RESOLUTIONS (moderator decisions)
CREATE TABLE IF NOT EXISTS dispute_resolutions (
  id SERIAL PRIMARY KEY,
  dispute_id INTEGER NOT NULL REFERENCES disputes(id) ON DELETE CASCADE,
  moderator_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  decision VARCHAR(30) NOT NULL,
  -- Decisions: 'confirm_result', 'reverse_result', 'refund_all', 'partial_adjustment'
  
  notes TEXT,
  new_winning_option_id INTEGER REFERENCES challenge_options(id),
  
  created_at TIMESTAMP DEFAULT NOW(),
  
  CONSTRAINT valid_decision CHECK (
    decision IN ('confirm_result', 'reverse_result', 'refund_all', 'partial_adjustment')
  )
);

CREATE INDEX idx_resolutions_dispute ON dispute_resolutions(dispute_id);
CREATE INDEX idx_resolutions_moderator ON dispute_resolutions(moderator_id);

-- 7. PAYOUT JOBS (async task queue)
CREATE TABLE IF NOT EXISTS payout_jobs (
  id SERIAL PRIMARY KEY,
  challenge_id INTEGER NOT NULL REFERENCES challenges(id) ON DELETE CASCADE,
  
  status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'processing', 'completed', 'failed'
  
  attempt_count INTEGER DEFAULT 0,
  max_attempts INTEGER DEFAULT 3,
  
  error_message TEXT,
  
  -- Idempotency
  idempotency_key VARCHAR(255) UNIQUE,
  
  created_at TIMESTAMP DEFAULT NOW(),
  started_at TIMESTAMP,
  completed_at TIMESTAMP,
  
  CONSTRAINT valid_job_status CHECK (status IN ('pending', 'processing', 'completed', 'failed'))
);

CREATE INDEX idx_payout_jobs_challenge ON payout_jobs(challenge_id);
CREATE INDEX idx_payout_jobs_status ON payout_jobs(status);
CREATE INDEX idx_payout_jobs_idempotency ON payout_jobs(idempotency_key);

-- ============================================
-- FUNCTIONS & TRIGGERS
-- ============================================

-- Auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_challenges_updated_at BEFORE UPDATE ON challenges
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Auto-set dispute deadline (72 hours)
CREATE OR REPLACE FUNCTION set_dispute_deadline()
RETURNS TRIGGER AS $$
BEGIN
  NEW.deadline = NEW.created_at + INTERVAL '72 hours';
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER set_dispute_deadline_trigger BEFORE INSERT ON disputes
  FOR EACH ROW EXECUTE FUNCTION set_dispute_deadline();

-- ============================================
-- INITIAL DATA
-- ============================================

-- Add 'moderator' role to users if not exists
-- (This will be handled by user management system)

