-- Vector Destiny Tables

-- Таблица профилей пользователей
CREATE TABLE IF NOT EXISTS vector_profiles (
    id SERIAL PRIMARY KEY,
    user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    full_name VARCHAR(255),
    gender VARCHAR(20),
    birth_date DATE NOT NULL,
    birth_time TIME,
    birth_place_city VARCHAR(255),
    birth_place_country VARCHAR(255),
    birth_latitude DECIMAL(10, 8),
    birth_longitude DECIMAL(11, 8),
    birth_timezone VARCHAR(100),
    sun_sign VARCHAR(50),
    moon_sign VARCHAR(50),
    rising_sign VARCHAR(50),
    birth_chart_data JSONB,
    responses JSONB DEFAULT '{}',
    focus_areas TEXT[],
    life_phase VARCHAR(50),
    personality_style VARCHAR(50),
    membership_level VARCHAR(10) DEFAULT 'GS-I',
    language VARCHAR(10) DEFAULT 'en',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Таблица подписок (без оплат - доступ по GS уровню)
CREATE TABLE IF NOT EXISTS vector_subscriptions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    profile_id INTEGER REFERENCES vector_profiles(id) ON DELETE CASCADE,
    membership_level VARCHAR(10) NOT NULL DEFAULT 'GS-I',
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    forecast_frequency VARCHAR(20) NOT NULL DEFAULT 'monthly', -- monthly, biweekly, weekly, daily
    last_forecast_date DATE,
    next_forecast_date DATE,
    forecasts_received INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Таблица прогнозов
CREATE TABLE IF NOT EXISTS vector_forecasts (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    profile_id INTEGER REFERENCES vector_profiles(id) ON DELETE CASCADE,
    forecast_date DATE NOT NULL,
    forecast_type VARCHAR(50) NOT NULL, -- 'daily', 'weekly', 'biweekly', 'monthly'
    membership_level VARCHAR(10) NOT NULL,
    content JSONB NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(user_id, forecast_date, forecast_type)
);

-- Таблица истории прогнозов
CREATE TABLE IF NOT EXISTS vector_forecast_history (
    id SERIAL PRIMARY KEY,
    subscription_id INTEGER REFERENCES vector_subscriptions(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    forecast_id INTEGER REFERENCES vector_forecasts(id),
    forecast_date DATE NOT NULL,
    forecast_type VARCHAR(20) NOT NULL, -- 'daily', 'weekly', 'biweekly', 'monthly'
    sent_at TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Таблица вопросов анкеты
CREATE TABLE IF NOT EXISTS vector_questions (
    id SERIAL PRIMARY KEY,
    membership_level VARCHAR(10) NOT NULL, -- 'all', 'GS-I', 'GS-II', 'GS-III', 'GS-IV'
    question_text TEXT NOT NULL,
    question_type VARCHAR(50) NOT NULL, -- 'text', 'select', 'multiple', 'date', etc
    options JSONB,
    order_index INTEGER NOT NULL,
    category VARCHAR(100),
    required BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Индексы для производительности
CREATE INDEX IF NOT EXISTS idx_vector_profiles_user ON vector_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_vector_subscriptions_user ON vector_subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_vector_forecast_history_user ON vector_forecast_history(user_id);
CREATE INDEX IF NOT EXISTS idx_vector_forecasts_user ON vector_forecasts(user_id);
CREATE INDEX IF NOT EXISTS idx_vector_forecasts_date ON vector_forecasts(forecast_date);
CREATE INDEX IF NOT EXISTS idx_vector_questions_level ON vector_questions(membership_level);

-- Вставляем базовые вопросы анкеты

-- Вопрос о языке (самый первый)
INSERT INTO vector_questions (membership_level, question_text, question_type, options, order_index, category, required) VALUES
('all', 'What is your preferred language?', 'select', '["English", "Russian", "Spanish", "French", "German", "Chinese", "Japanese", "Arabic", "Portuguese", "Italian", "Other"]', 0, 'language', TRUE);

-- Основные вопросы (доступны всем)
INSERT INTO vector_questions (membership_level, question_text, question_type, options, order_index, category, required) VALUES
('all', 'What is your full name?', 'text', NULL, 1, 'basic', TRUE),
('all', 'What is your gender?', 'select', '["Male", "Female", "Other", "Prefer not to say"]', 2, 'basic', TRUE),
('all', 'What is your date of birth?', 'date', NULL, 3, 'basic', TRUE),
('all', 'What time were you born? (if known)', 'time', NULL, 4, 'basic', FALSE),
('all', 'In which city were you born?', 'text', NULL, 5, 'basic', TRUE),
('all', 'In which country were you born?', 'text', NULL, 6, 'basic', TRUE);

-- Все вопросы теперь доступны для GS-I (после активации получают все вопросы)
INSERT INTO vector_questions (membership_level, question_text, question_type, options, order_index, category, required) VALUES
('GS-I', 'What are your main areas of interest?', 'multiple', '["Career", "Relationships", "Health", "Finance", "Personal Growth", "Family", "Spirituality"]', 10, 'interests', TRUE),
('GS-I', 'What is your current life phase?', 'select', '["Student", "Young Professional", "Established Career", "Mid-Life Transition", "Retirement Planning", "Retired"]', 11, 'life_phase', TRUE),
('GS-I', 'What best describes your personality style?', 'select', '["Analytical", "Creative", "Practical", "Social", "Intuitive", "Adventurous"]', 12, 'personality', TRUE),
('GS-I', 'What are your primary career goals?', 'textarea', NULL, 13, 'career', FALSE),
('GS-I', 'What relationship status best describes you?', 'select', '["Single", "In a Relationship", "Married", "Divorced", "Widowed", "Complicated"]', 14, 'relationships', FALSE),
('GS-I', 'What financial goals are most important to you?', 'multiple', '["Wealth Building", "Debt Freedom", "Investment Growth", "Business Success", "Financial Security", "Passive Income"]', 15, 'finance', FALSE),
('GS-I', 'Describe a significant life challenge you are currently facing', 'textarea', NULL, 16, 'challenges', FALSE),
('GS-I', 'What spiritual practices do you engage in?', 'multiple', '["Meditation", "Prayer", "Yoga", "Energy Work", "Mindfulness", "None", "Other"]', 17, 'spiritual', FALSE),
('GS-I', 'What are your top 3 life priorities right now?', 'textarea', NULL, 18, 'priorities', FALSE),
('GS-I', 'What is your vision for your life 5 years from now?', 'textarea', NULL, 19, 'vision', FALSE),
('GS-I', 'What limiting beliefs would you like to overcome?', 'textarea', NULL, 20, 'beliefs', FALSE),
('GS-I', 'What legacy do you want to leave?', 'textarea', NULL, 21, 'legacy', FALSE),
('GS-I', 'Describe your ideal day in detail', 'textarea', NULL, 22, 'ideal_life', FALSE);

-- Комментарий
COMMENT ON TABLE vector_profiles IS 'Астрологические профили пользователей Vector Destiny';
COMMENT ON TABLE vector_subscriptions IS 'Подписки на прогнозы Vector Destiny (без оплат)';
COMMENT ON TABLE vector_forecast_history IS 'История отправленных прогнозов';
COMMENT ON TABLE vector_forecasts IS 'Астрологические прогнозы';
COMMENT ON TABLE vector_questions IS 'Вопросы анкеты Vector Destiny';

