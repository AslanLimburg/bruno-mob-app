-- Создание таблицы для swap транзакций
CREATE TABLE IF NOT EXISTS swap_transactions (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  from_token VARCHAR(10) NOT NULL,
  to_token VARCHAR(10) NOT NULL,
  from_amount DECIMAL(18, 8) NOT NULL,
  to_amount DECIMAL(18, 8) NOT NULL,
  commission DECIMAL(18, 8) DEFAULT 0,
  tx_hash VARCHAR(255),
  recipient_address VARCHAR(255),
  type VARCHAR(50) NOT NULL, -- 'crypto_to_brt', 'brt_to_crypto', 'crypto_to_crypto'
  status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'completed', 'failed'
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Индексы для быстрого поиска
CREATE INDEX idx_swap_user_id ON swap_transactions(user_id);
CREATE INDEX idx_swap_tx_hash ON swap_transactions(tx_hash);
CREATE INDEX idx_swap_created_at ON swap_transactions(created_at DESC);

-- Создание таблицы для резерва BRTC (капитализация)
CREATE TABLE IF NOT EXISTS brtc_reserve (
  id SERIAL PRIMARY KEY,
  transaction_type VARCHAR(50) NOT NULL, -- 'crypto_to_brt', 'brt_to_crypto', 'crypto_to_crypto'
  amount_received DECIMAL(18, 8) NOT NULL,
  currency_received VARCHAR(10) NOT NULL,
  amount_sent DECIMAL(18, 8) NOT NULL,
  currency_sent VARCHAR(10) NOT NULL,
  commission DECIMAL(18, 8) DEFAULT 0,
  gas_fee DECIMAL(18, 8) DEFAULT 0,
  profit DECIMAL(18, 8) DEFAULT 0, -- commission - gas_fee
  created_at TIMESTAMP DEFAULT NOW()
);

-- Индекс для статистики
CREATE INDEX idx_brtc_reserve_created_at ON brtc_reserve(created_at DESC);

-- Создание таблицы для crypto транзакций (on-chain)
CREATE TABLE IF NOT EXISTS crypto_transactions (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  type VARCHAR(20) NOT NULL, -- 'send', 'receive'
  token VARCHAR(10) NOT NULL,
  amount DECIMAL(18, 8) NOT NULL,
  recipient_address VARCHAR(255),
  tx_hash VARCHAR(255) UNIQUE NOT NULL,
  chain VARCHAR(20) NOT NULL, -- 'BSC', 'ETHEREUM', 'TRON'
  status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'confirmed', 'failed'
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Индексы
CREATE INDEX idx_crypto_tx_user_id ON crypto_transactions(user_id);
CREATE INDEX idx_crypto_tx_hash ON crypto_transactions(tx_hash);
CREATE INDEX idx_crypto_tx_created_at ON crypto_transactions(created_at DESC);

-- Добавляем поле brt_balance в users если его нет
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='users' AND column_name='brt_balance') THEN
    ALTER TABLE users ADD COLUMN brt_balance DECIMAL(18, 8) DEFAULT 0;
  END IF;
END $$;

-- Добавляем индекс для brt_balance
CREATE INDEX IF NOT EXISTS idx_users_brt_balance ON users(brt_balance);