-- Migration: Add role column to users table
-- Date: 2025-10-15

-- Add role column with default value 'user'
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS role VARCHAR(20) DEFAULT 'user';

-- Create index for faster role-based queries
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

-- Update admin account to have admin role
UPDATE users 
SET role = 'admin' 
WHERE email = 'admin@brunotoken.com';

-- Update existing test user to moderator for testing
UPDATE users 
SET role = 'moderator' 
WHERE email = 'test@test.com';

-- Display updated users with roles
SELECT id, email, role, account_status 
FROM users 
ORDER BY id;
