const lotteryController = require('./controllers/lotteryController');

console.log('lotteryController:', lotteryController);
console.log('buyTicket:', lotteryController.buyTicket);
console.log('getCurrentDraw:', lotteryController.getCurrentDraw);
